
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `salt` char(16) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activation` varchar(40) DEFAULT NULL,
  `dana_ver` int NOT NULL DEFAULT 0,
  `last_login`  DATETIME DEFAULT NULL,
  `created`  DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;

/* COMMENT: 'desc' field name is reserved in mysql */
/* http://bugs.mysql.com/bug.php?id=50883 */

CREATE TABLE `decks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1024) NOT NULL,
  `description` varchar(1024) NULL,
  `tags` varchar(1024) NULL,
  `author` varchar(1024) NULL,
  `guid` char(38) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `icon` varchar(1024) NULL,
  `rating` float NOT NULL DEFAULT 0,
  `downloads` int NOT NULL DEFAULT 0,
  `cards_no` int NOT NULL DEFAULT 0,
  `flags` int unsigned NOT NULL DEFAULT 0,
  `created` DATETIME NOT NULL ,
  `updated` DATETIME NOT NULL ,
  `dana_ver` int NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE `votes` (
  `id` int(11)  NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `deck_id` int NOT NULL,
  `rating` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX (`user_id`),
  INDEX (`deck_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1