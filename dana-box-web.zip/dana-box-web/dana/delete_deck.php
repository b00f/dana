<?php
    require_once("utils.php");
    require_once("restricted.php");

    $deck_id  = intval ($_GET['deck_id']);

    if($deck_id)
    {
        delete_deck($deck_id);

        die('deck deleted');
    }
?>