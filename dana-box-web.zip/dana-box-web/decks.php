﻿<?php $tab='decks'; include('header.php'); ?>
<p>
You can find deck list by using dana application. <br />
I am still working on showing decks on this page, It's under construction. <br />
thanks for your patient.<br />
</p>
 <?include 'footer.php'; ?>
