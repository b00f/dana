﻿<?php $tab='index'; include('header.php'); ?>

<div>
<h2 class="featurette-heading">Dana, Symbol of Wisdom <!--<span class="text-muted">Knowledge is Power.</span>--></h2>
<p class="lead">

<h3>About name:</h3>
<p>'Dana' has several meanings. In English 'Dana' (pronounced  /ˈdɑːnə/) is a giving name for girls. It was a popular name in middle of 20th century at USA. It's feminine name for 'Daneil'.</p>
<p>'Dana' can also refer to 'Danu', Irish goddess. </p>
<p>Czechs use it as a feminine form of the biblical name 'Dan' or a short form for 'Daniela' and 'Bohdana'.</p>
<p>This name is used mainly by Arabs of the Persian Gulf, due to their traditional pearl diving professions wherein they gave different type of pearls names. It is used in the Arab world as a female name.</p>
<p>In Persian 'Dana' is a name for both girls and boys. It means 'Knowledge' or 'Wisdom'. A proverb in Persian says: 'Knowledge is Ability' (دانایی توانایی است.).</p>
<p>"ipsa scientia potestas est" is a Latin aphorism that means 'knowledge itself is power' or 'wisdom is power' that Sir Francis Bacon used it.</p>

<h3>About icon:</h3>
<p>If you are thinking the icon of 'Dana' is looks like a spider web, you are not so far away.</p>
<p>Actually it is, but in West Africa it's a symbol of 'Wisdom' and 'Creativity!</p>
<p>Ananse, the spider, is a well-known character in African folk-tales.</p>
'Dana' is an open source and free software for whom want to extend their knowledge!<br />
Please consider that there is no warranty for using 'Dana'. no support line! But before releasing this software I tested it more than one month and also I asked my friend to test it. It should be a bug free software, But for any possible bugs, please accept our apologise.<br />
</p>
</div>

<?include 'footer.php'; ?>