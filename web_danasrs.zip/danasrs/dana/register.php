<?php 
	require("utils.php"); 
     
	$error = array();//Declare An Array to store any error message  
	
	$email = ''; 
	$password = ''; 
	$username = ''; 
	
    // This if statement checks to determine whether the registration form has been submitted 
    // If it has, then the registration code is run, otherwise the form is displayed 
    if(!empty($_POST)) 
    {
		$email = $_POST['email'];
		$password = $_POST['password'];
		$username = $_POST['username']; 
	
        // Ensure that the user has entered a non-empty name 
        if(empty($username)) 
        { 
            // Note that die() is generally a terrible way of handling user errors 
            // like this.  It is much better to display the error with the form 
            // and allow the user to correct their mistake.  However, that is an 
            // exercise for you to implement yourself. 
            $error[] = ("Please enter a name."); 
        } 
         
        // Ensure that the user has entered a non-empty password 
        if(empty($password)) 
        { 
            $error[] = ("Please enter a password."); 
        } 
         
        // Make sure the user entered a valid E-Mail address 
        // filter_var is a useful PHP function for validating form input, see: 
        // http://us.php.net/manual/en/function.filter-var.php 
        // http://us.php.net/manual/en/filter.filters.php 
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)) 
        { 
            $error[] = ("Invalid E-Mail Address"); 
        } 
         
		//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
		// cehck user name
		if (empty($error)) 
		{
			// We will use this SQL query to see whether the username entered by the 
            // user is already in use.  A SELECT query is used to retrieve data from the database. 
            // :username is a special token, we will substitute a real value in its place when 
            // we execute the query. 
            $query = " 
                SELECT 
                    1 
                FROM users 
                WHERE 
                    username = :username 
            "; 
             
            // This contains the definitions for any special tokens that we place in 
            // our SQL query.  In this case, we are defining a value for the token 
            // :username.  It is possible to insert $_POST['username'] directly into 
            // your $query string; however doing so is very insecure and opens your 
            // code up to SQL injection exploits.  Using tokens prevents this. 
            // For more information on SQL injections, see Wikipedia: 
            // http://en.wikipedia.org/wiki/SQL_Injection 
            $query_params = array( 
                ':username' => $username 
            ); 
             
            try 
            { 
                // These two statements run the query against your database table. 
                $stmt = $db->prepare($query); 
                
                $stmt->execute($query_params); 
            } 
            catch(PDOException $ex) 
            { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: " . $ex->getMessage()); 
            } 
             
            // The fetch() method returns an array representing the "next" row from 
            // the selected results, or false if there are no more rows to fetch. 
            $row = $stmt->fetch(); 
             
            // If a row was returned, then we know a matching username was found in 
            // the database already and we should not allow the user to continue. 
            if($row) 
            { 
                $error[] = ("This username is already in use. Please choose another one"); 
            }
		}
		
		//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
		// cehck email
		if (empty($error)) 
		{
			// Now we perform the same type of check for the email address, in order 
            // to ensure that it is unique. 
            $query = " 
                SELECT 
                    1 
                FROM users 
                WHERE 
                    email = :email 
            "; 
             
            $query_params = array( 
                ':email' => $email
            ); 
             
            try 
            { 
                $stmt = $db->prepare($query); 
                
                $stmt->execute($query_params); 
            } 
            catch(PDOException $ex) 
            { 
                die("Failed to run query: " . $ex->getMessage()); 
            } 
             
            $row = $stmt->fetch(); 
             
            if($row) 
            { 
                $error[] = ("This email is already in use. if you forget your password you can obtain it <a href='forgot_password.php'>here</a>"); 
            }
		}
		
		//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
		// Add to database
		if (empty($error)) 
		{
			$activation = sha1(uniqid(rand(), true));
			
            // An INSERT query is used to add new rows to a database table. 
            // Again, we are using special tokens (technically called parameters) to 
            // protect against SQL injection attacks. 
            $query = " 
                INSERT INTO users ( 
                    username, 
                    password, 
                    salt, 
                    email,
					activation,
                    created
                ) VALUES ( 
                    :username, 
                    :password, 
                    :salt, 
                    :email,
					:activation,
                    NOW()
                ) 
            "; 
             
            // A salt is randomly generated here to protect again brute force attacks 
            // and rainbow table attacks.  The following statement generates a hex 
            // representation of an 8 byte salt.  Representing this in hex provides 
            // no additional security, but makes it easier for humans to read. 
            // For more information: 
            // http://en.wikipedia.org/wiki/Salt_%28cryptography%29 
            // http://en.wikipedia.org/wiki/Brute-force_attack 
            // http://en.wikipedia.org/wiki/Rainbow_table 
            $salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647)); 

            $password = hash_password($password, $salt); 
                             
            // Here we prepare our tokens for insertion into the SQL query.  We do not 
            // store the original password; only the hashed version of it.  We do store 
            // the salt (in its plaintext form; this is not a security risk). 
			$email = $email;
			$username = $username;
			
            $query_params = array( 
                ':username' => $username, 
                ':password' => $password, 
                ':salt' => $salt, 
                ':email' => $email,
				':activation' => $activation
            ); 
             
            try 
            { 
                // Execute the query to create the user 
                $stmt = $db->prepare($query); 
                $result = $stmt->execute($query_params); 
				
				if($result)
				{
					send_confirmation_letter($activation, $email);
	 	            
					echo '<div class="success">Thank you for registering! A confirmation email has been sent to ' . $Email .
	                ' Please click on the Activation Link to activate your account. </div>';
				}
            }
            catch(PDOException $ex) 
            { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: " . $ex->getMessage()); 
            } 
             
			 /*
            // This redirects the user back to the login page after they register 
            header("Location: login.php"); 
             
            // Calling die or exit after performing a redirect using the header function 
            // is critical.  The rest of your PHP script will continue to execute and 
            // will be sent to the user if you do not die or exit. 
            die("Redirecting to login.php"); 
			*/	
		}	
    }

	if(empty($error)==false)
	{
		echo '<div class="error"><ol>';
        foreach ($error as $key => $values) 
		{
            echo '<li>'.$values.'</li>';
		}
		echo '</ol></div>';
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>  
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dana - Register</title>
<link rel="stylesheet" href="style.css" />
<script language="JavaScript" type="text/javascript"> 
<!--
   function FixFields()
   {
	  document.getElementById("username").value = document.getElementById("f6Lx571p").value;
      document.getElementById("email").value    = document.getElementById("f7ehr93h").value;
      document.getElementById("password").value	= document.getElementById("4nu5slo9").value;
   }
// -->
</script>
</head> 
<body>  
<form action="register.php" method="post" name="myForm"  onsubmit="FixFields();">
  <fieldset>
    <legend>Registration Form </legend>
    <p>Create A new Account
	<span class="link">Already a member? <a href="login.php">Log in</a></span></p>
	<input type="hidden" id="username" name="username" value="" />
	<input type="hidden" id="email" name="email" value="" />
	<input type="hidden" id="password" name="password" value="" />
	<div class="elements">
      <label for="f6Lx571p">Name :</label>
      <input type="text" id="f6Lx571p" name="f6Lx571p" size="25" maxlength="64" value="<?php echo $username ?>"/>
    </div>
    <div class="elements">
      <label for="f7ehr93h">E-mail :</label>
      <input type="text" id="f7ehr93h" name="f7ehr93h" size="25"  maxlength="128" value="<?php echo $email ?>"/>
    </div>
    <div class="elements">
      <label for="4nu5slo9">Password:</label>
      <input type="password" id="4nu5slo9" name="4nu5slo9" size="25" maxlength="64" value=""/>
    </div>
    <div class="submit">
      <input type="submit" value="Register" />
    </div>
  </fieldset>
  <p>
    <b>Notes:</b>
    <ul>
        <li>Your email just uses for verification.</li>
        <li>You won't recieved any kind of newsletter, notification or any other letters.</li>
        <li>your password will be hashed and <a href="http://en.wikipedia.org/wiki/Salt_(cryptography)">salted</a> before saving in database.</li>
    </ul>
  </p>
</form> 
</body> 
</html>