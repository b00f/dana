<?php
	require("common.php"); 
    require("url_to_absolute.php");
	
	// This block of code is used to undo magic quotes.  Magic quotes are a terrible 
	// feature that was removed from PHP as of PHP 5.4.  However, older installations 
	// of PHP may still have magic quotes enabled and this code is necessary to 
	// prevent them from causing problems.  For more information on magic quotes: 
	// http://php.net/manual/en/security.magicquotes.php 
	if(function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc()) 
	{ 
		function undo_magic_quotes_gpc(&$array) 
		{ 
			foreach($array as &$value) 
			{ 
				if(is_array($value)) 
				{ 
					undo_magic_quotes_gpc($value); 
				} 
				else 
				{ 
					$value = stripslashes($value); 
				} 
			} 
		} 
	
		undo_magic_quotes_gpc($_POST); 
		undo_magic_quotes_gpc($_GET); 
		undo_magic_quotes_gpc($_COOKIE); 
	} 
	
	function hash_password($password, $salt)
	{
		// This hashes the password with the salt so that it can be stored securely 
		// in your database.  The output of this next statement is a 64 byte hex 
		// string representing the 32 byte sha256 hash of the password.  The original 
		// password cannot be recovered from the hash.  For more information: 
		// http://en.wikipedia.org/wiki/Cryptographic_hash_function 
		$hashed_password = hash('sha256', $password . $salt); 
		
		// Next we hash the hash value 65536 more times.  The purpose of this is to 
		// protect against brute force attacks.  Now an attacker must compute the hash 65537 
		// times for each guess they make against a password, whereas if the password 
		// were hashed only once the attacker would have been able to make 65537 different  
		// guesses in the same amount of time instead of only one. 
		for($round = 0; $round < 65536; $round++) 
		{ 
			$hashed_password = hash('sha256', $hashed_password . $salt); 
		}
		
		return $hashed_password;
	}
	
	function send_confirmation_letter($activation, $email)
	{
		// Send the email:
		$message = "To activate your account, please click on this link:\n\n";
		$message .=  'http://danasrs.com/dana/activate.php?email=' . urlencode($email) . "&key=$activation\n\n";
		$message .=  "You must activate your account to login.\nThanks"; 
		mail($email, 'Dana: Registration Confirmation', $message, 'From: admin@danasrs.com');
	}
	
	function send_password($password, $email)
	{
		// Send the email:
		$message =   "Your new password:\n$password\n\n";
		$message .=  "Login here \n http://danasrs.com/dana/login.php?email=" . urlencode($email) . "\n\n";
		$message .=  "Thanks"; 
		mail($email, 'Dana: Password Recovery', $message, 'From: admin@danasrs.com');
	}
	
	function upload_file($file, $allowed_ext, $max_size_mb, $rel_path)
	{
		$tmp        = $_FILES[$file]['tmp_name'];
		$file_name  = $_FILES[$file]['name'];
		$file_size  = $_FILES[$file]['size'];
        $file_type  = $_FILES[$file]['type'];
        $tmp_name   = $_FILES[$file]['tmp_name'];
        $error      = $_FILES[$file]['error'];
        $dest_path  = $_SERVER['DOCUMENT_ROOT'] . $rel_path;
		
        if($error)
		{
			die('Uploading Error:  '. $error);
		}
        else
        {
            /// echo "Upload: "    . $file_name . "<br>\n";
            /// echo "Type: "      . $file_type . "<br>\n";
            /// echo "Size: "      . $file_size . " bytes<br>\n";
            /// echo "Stored in: " . $tmp_name  . "<br>\n";
        }
        
		$ext = explode(".", $file_name);
        $ext = end( $ext );
        /// $ext = pathinfo($filename, PATHINFO_EXTENSION);
		if($ext != $allowed_ext) // extension
		{
			die('Uploading Error: wrong extension' . $ext);
		}
	
        if($file_size > ($max_size_mb*1024*1024))
		{
			die('Uploading Error: Your file\'s size is to large. It should be less than ' . $max_size_mb. ' mb');
		}
        	
		if(!is_uploaded_file($tmp_name))
		{
			die('Uploading Error: Cannot upload the file');
		}
        
        $dir = pathinfo($dest_path, PATHINFO_DIRNAME);
        if (!is_dir($dir))
        {
            mkdir($dir);
        }
        
		if(!move_uploaded_file($tmp_name, $dest_path))
		{
			die('Unknown Error');
		}
	}
	
	function is_valid_guid($guid)
	{
		return !empty($guid) && preg_match('/^\{?[A-Z0-9]{8}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{12}\}?$/', $guid);
	}
	
	function check_user($email, $password, $dana_ver = 0)
	{
	    global $db;
		$error = array();//Declare An Array to store any error message  
		
		// This query retreives the user's information from the database using 
		// their username. 
		$query = " 
			SELECT 
				id, 
				username, 
				password, 
				salt, 
				email,
				activation
			FROM users 
			WHERE 
				email = :email
		"; 
		
		// The parameter values 
		$query_params = array( 
			':email' => $email 
		); 
		
		try 
		{ 
			// Execute the query against the database 
			$stmt = $db->prepare($query); 
			
            $stmt->execute($query_params); 
		} 
		catch(PDOException $ex) 
		{ 
			// Note: On a production website, you should not output $ex->getMessage(). 
			// It may provide an attacker with helpful information about your code.  
			die("Failed to run query: " . $ex->getMessage()); 
		} 
		
		// This variable tells us whether the user has successfully logged in or not. 
		// We initialize it to false, assuming they have not. 
		// If we determine that they have entered the right details, then we switch it to true. 
		$login_ok = false; 
		
		// Retrieve the user data from the database.  If $row is false, then the username 
		// they entered is not registered. 
		$row = $stmt->fetch(); 
		if($row) 
		{
			$activation = $row['activation'];
			if(!is_null($activation))
			{
				/// not activated yet
				$error[] = ("Your account is not activated yet. Please check your email for activation code."); 
			}
			else
			{
				$password = hash_password($password, $row['salt']); 
				if($password == $row['password']) 
				{ 
					// If they do, then we flip this to true 
					$login_ok = true; 
				}
				else
				{
					$error[] = ("Password does not match."); 
				}
			}
		}
		else
		{
			$error[] = ("This email is not registered."); 	
		}
		
		// If the user logged in successfully, then we send them to the private members-only page 
		// Otherwise, we display a login failed message and show the login form again 
		if($login_ok) 
		{
            /// update record
            
            //// ======================================================
            $query_params = array( 
                ':user_id' => $row['id'],
            );
            
            $query = " 
                UPDATE users 
                SET 
                    last_login = NOW()
                "; 
     
            if( $dana_ver != 0&& 
                $dana_ver != $row['dana_ver']) 
            {
                $query_params[':dana_ver'] = $dana_ver;
                
                $query .= " 
                    , dana_ver = :dana_ver 
                "; 
            } 

            $query .= " 
                WHERE 
                    id = :user_id 
            ";
            
            try 
            { 
                // Execute the query 
                $stmt = $db->prepare($query); 
                $result = $stmt->execute($query_params); 
            } 
            catch(PDOException $ex) 
            { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: " . $ex->getMessage()); 
            }
            //// ======================================================
        
			// Here I am preparing to store the $row array into the $_SESSION by 
			// removing the salt and password values from it.  Although $_SESSION is 
			// stored on the server-side, there is no reason to store sensitive values 
			// in it unless you have to.  Thus, it is best practice to remove these 
			// sensitive values first. 
			unset($row['salt']); 
			unset($row['password']); 
			
			// This stores the user's data into the session at the index 'user'. 
			// We will check this index on the private members-only page to determine whether 
			// or not the user is logged in.  We can also use it to retrieve 
			// the user's details. 
			$_SESSION['user'] = $row; 
		} 
		else 
		{ 
			// Tell the user they failed 
			///print("Login Failed."); 
			
			// Show them their username again so all they have to do is enter a new 
			// password.  The use of htmlentities prevents XSS attacks.  You should 
			// always use htmlentities on user submitted values before displaying them 
			// to any users (including the user that submitted them).  For more information: 
			// http://en.wikipedia.org/wiki/XSS_attack 
			$submitted_email = htmlentities($email, ENT_QUOTES, 'UTF-8'); 
		}
		
		return $error;
	}
	
	function update_account($username, $password)
	{
        if(empty($_SESSION['user'])) 
            return; /// not a valid session

        global $db;
		$error = array();//Declare An Array to store any error message  
		$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647)); 
		
		if(!empty($password)) 
		{ 
			$password = hash_password($password, $salt); 
		} 
		else 
		{ 
			// If the user did not enter a new password we will not update their old one. 
			$password = null; 
			$salt = null; 
		} 
     
		// Initial query parameter values 
		$query_params = array( 
			':username' => $username, 
			':user_id' => $_SESSION['user']['id'], 
		); 
     
		// If the user is changing their password, then we need parameter values 
		// for the new password hash and salt too. 
		if($password !== null) 
		{ 
			$query_params[':password'] = $password; 
			$query_params[':salt'] = $salt; 
		} 
     
		// Note how this is only first half of the necessary update query.  We will dynamically 
		// construct the rest of it depending on whether or not the user is changing 
		// their password. 
		$query = " 
			UPDATE users 
			SET 
				username = :username 
		"; 
     
		// If the user is changing their password, then we extend the SQL query 
		// to include the password and salt columns and parameter tokens too. 
		if($password !== null) 
		{ 
			$query .= " 
				, password = :password 
				, salt = :salt 
			"; 
		} 
     
		// Finally we finish the update query by specifying that we only wish 
		// to update the one record with for the current user. 
		$query .= " 
			WHERE 
				id = :user_id 
		"; 
     
		try 
		{ 
			// Execute the query 
			$stmt = $db->prepare($query); 
			
            $stmt->execute($query_params); 
		} 
		catch(PDOException $ex) 
		{ 
			// Note: On a production website, you should not output $ex->getMessage(). 
			// It may provide an attacker with helpful information about your code.  
			die("Failed to run query: " . $ex->getMessage()); 
		}
        
        // Now that the user's E-Mail address has changed, the data stored in the $_SESSION 
		// array is stale; we need to update it so that it is accurate. 
		$_SESSION['user']['username'] = $username; 

		return $error;		
	}
    
    function get_decks_by_user_id($user_id)
	{
        global $db;
        
		$query = " 
			SELECT 
				* 
			FROM decks 
			WHERE 
				user_id = :user_id
		"; 
		
		$query_params = array( 
			':user_id' => $user_id 
		); 
		
		try 
		{ 
			$stmt = $db->prepare($query); 
			
            $stmt->execute($query_params); 
		} 
		catch(PDOException $ex) 
		{
			die("Failed to run query: " . $ex->getMessage()); 
		} 
		
		$rows = $stmt->fetchAll (PDO::FETCH_ASSOC); 
	
		return $rows;
	}
    
    function check_deck_by_guid($guid)
	{
        global $db;
        
        $user_id   = $_SESSION['user']['id'];
        
		$query = " 
			SELECT 
				user_id 
			FROM decks 
			WHERE 
				guid = :guid
		"; 
		
		$query_params = array( 
			':guid' => $guid 
		); 
		
		try 
		{ 
			$stmt = $db->prepare($query); 
			
            $stmt->execute($query_params); 
		} 
		catch(PDOException $ex) 
		{
			die("Failed to run query: " . $ex->getMessage()); 
		} 
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC); 
	
		if(empty($row))
            return 0;
            
        if($row['user_id']!=$user_id)
            return -1;
        
        return 1;
	}
    
    /**
    * @param mysql_resource - $queryResult - mysql query result
    * @param string - $rootElementName - root element name
    * @param string - $childElementName - child element name
    **/
    function pdo2xml($stmt, $rootElementName, $childElementName)
    {        
        $xmlData = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n"; 
        $xmlData .= "<" . $rootElementName . ">";
    
        while($row = $stmt->fetchObject())
        {
            /* Create the first child element */
            $xmlData .= "<" . $childElementName . ">";

            $iterator = new ArrayIterator($row);
           
            for ($i = 0; $i < $stmt->columnCount(); $i++)
            { 
                $iterator->seek($i);
                $meta = $stmt->getColumnMeta($i);
                /* The child will take the name of the table column */
                $xmlData .= "<" . $meta['name'] . ">";
   
                $xmlData .= $iterator->current();; 
                
                $xmlData .= "</" . $meta['name'] . ">"; 
            } 
            $xmlData .= "</" . $childElementName . ">"; 
        } 
        $xmlData .= "</" . $rootElementName . ">"; 
    
        return $xmlData; 
    }
    
    function vote($deck_id, $rating)
    {
        if(empty($_SESSION['user'])) 
            return; /// not a valid session

        global $db;
        
        if($rating > 5) $rating =5;
        if($rating < 0) $rating =0;
        
        $user_id   = $_SESSION['user']['id'];    

        //// --- update votes table
        $query_params = array( 
            ':deck_id' => $deck_id,
            ':user_id' => $user_id,
        );
    
        $query = "  
                SELECT id, rating
                FROM   votes 
                WHERE  user_id = :user_id AND deck_id = :deck_id 
            "; 
        try 
        {
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
        $query_params[':rating'] = $rating;
        
        if(empty($row))
        {
            $query = "  
                INSERT INTO votes( user_id,  deck_id,  rating)
                VALUES           (:user_id, :deck_id, :rating)
            ";   
        }
        else
        {
            $query_params[':vote_id'] = $row['id'];
            unset($query_params[':user_id']);
            unset($query_params[':deck_id']);
            
            $query = "  
                UPDATE  votes
                SET     rating = :rating
                WHERE   id = :vote_id
            ";
        }
        
        try 
        {
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
        
        
        //// --- update deck table
        unset($query_params);
        
        $query_params = array(
            ':deck_id' => $deck_id
        );
            
        $query = "  
            SELECT SUM(rating) as ratings, count(*) as votes
            FROM   votes 
            WHERE  deck_id = :deck_id
        ";

        try 
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);            
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $query = "  
            UPDATE decks
            SET rating = :rating  
            WHERE id = :deck_id
        ";
       
        $query_params[':rating'] = $row['ratings'] / $row['votes'];
        
        try 
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
    }
    
    function delete_deck($deck_id)
    {
        if(empty($_SESSION['user'])) 
            return; /// not a valid session
            
        global $db;
        
        $query_params = array(
            ':deck_id' => intval($deck_id) ,
            ':user_id' => intval($_SESSION['user']['id'])
        );
        
        $query = "  DELETE  
                    FROM  votes 
                    WHERE deck_id = :deck_id AND user_id = :user_id";

        try 
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);            
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
               
        $query = "  DELETE  
                    FROM  decks 
                    WHERE id = :deck_id AND user_id = :user_id";

        try 
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);            
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }        
    }
    
    function share_deck($dana_ver, $name, $desc, $author, $tags, $cards_no, $guid, $created)
    {
        if(empty($_SESSION['user'])) 
            die('Please Login.');
         
        global $db;
         
        $user_id   = $_SESSION['user']['id'];
        $path      = "/decks/" . $guid . "/";
        $path      = "/decks/" . $guid . "/deck.dana";
        $icon      = "/decks/" . $guid . "/icon.png";

        /// $createdTime = DateTime::createFromFormat(DateTime::ISO8601, $created);                                                                     
        if(!is_valid_guid($guid))
        {
            die('wrong guid: ' . $guid);
        }
        
        $result = check_deck_by_guid($guid);
        if(result == -1)
        {
            die("A deck with this guid already exists. You are not authorized to change it."); 
        }

        upload_file('deck', 'dana', 10, $path);
        upload_file('icon', 'png', 1, $icon);

        
        // The parameter values 
        $query_params = array( 
            ':name'    => $name    ,
            ':desc'    => $desc    ,
            ':tags'    => $tags    ,
            ':author'  => $author  ,
            ':cards_no'=> $cards_no,
            ':created' => $created ,
            ':guid'    => $guid    ,
            ':path'    => $path    ,
            ':icon'    => $icon    ,
            ':dana_ver'=> $dana_ver,
        ); 
            
        if(result == 1)
        {
            $query = " 
                UPDATE      decks
                    SET     name         = :name        ,
                            description  = :desc        ,
                            tags         = :tags        ,
                            author       = :author      ,
                            cards_no     = :cards_no    ,
                            created      = :created     ,
                            guid         = :guid        ,
                            path         = :path        ,
                            icon         = :icon        ,
                            dana_ver     = :dana_ver    ,
                            updated      = NOW()        
                    WHERE   id           = :deck_id 
                ";

            $query_params[':deck_id'] = $row['id'];                
        }
        else
        {
            $query = " 
                INSERT INTO decks ( 
                            name, 
                            description, 
                            tags,
                            author, 
                            cards_no,
                            created,
                            guid,
                            path,
                            icon,
                            dana_ver,
                            updated,
                            user_id
                    ) VALUES ( 
                            :name, 
                            :desc, 
                            :tags,
                            :author, 
                            :cards_no,
                            :created,
                            :guid,
                            :path,
                            :icon,
                            :dana_ver,
                            NOW(),
                            :user_id
                    ) 
            "; 
            
            $query_params[':user_id'] = $user_id;
        }
        
        try 
        {
            $stmt = $db->prepare($query); 
            
            $ret_val = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
    }
    
    function get_decks()
    {
        global $db;
    
        $dana_ver  = $_POST['version'];
        $query = "SELECT * FROM decks"; 

        try 
        {
            $stmt = $db->query($query); 
        } 
        catch(PDOException $ex) 
        {
            die("Failed to run query: " . $ex->getMessage()); 
        }
        
        $rows = $stmt->fetchAll (PDO::FETCH_ASSOC); 
	
		return $rows;
    }
    
    function get_votes($deck_id)
    {
        global $db;
        
        $query = "SELECT count(*) as votes FROM votes WHERE deck_id = " . $deck_id; 
        $stmt_count = $db->query($query); 
        $row = $stmt_count->fetch(PDO::FETCH_ASSOC);
        
        return $row['votes'];
    }
    
    function download_deck($deck_id)
    {
        global $db;
        global $base_url;
        //// ======================================================
        //// select
        $query_params = array( 
            ':deck_id' => $deck_id,
        );
        
        $query = "  SELECT path, downloads
                    FROM   decks 
                    WHERE  id = :deck_id 
                "; 
        try 
        {
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if(empty($row))
        {
            die("wrong deck id");
        }
        //// ======================================================
        
        //// ======================================================
        //// update
        $query_params = array( 
            ':deck_id' => $deck_id,
            ':downloads' => $row[downloads]+1,
        );
        
        $query = "  UPDATE decks
                    SET    downloads = :downloads 
                    WHERE  id = :deck_id 
                "; 
                
        try 
        {
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        }
        //// ======================================================
        
        //$path = url_to_absolute($base_url, $row['path']);
        $file =  __DIR__ . '/..' . $row['path'];

        if (file_exists($file))
        {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename='.basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            
            readfile($file);
            exit;
        }
        else
        {
            die("File does not exist."); 
        }
    }
?>