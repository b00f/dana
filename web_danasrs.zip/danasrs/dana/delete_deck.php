<?php 
	require("utils.php");
	require("restricted.php");
    
    $deck_id  = intval ($_GET['deck_id']);
    
    if($deck_id)
    {
        delete_deck($deck_id);
        
        die('deck deleted');
    }
?> 