<?php 
	require("utils.php"); 
    /* Sql query */
    $query = "SELECT * FROM decks"; 

	
	try 
	{
        global $db;
		$stmt = $db->query($query); 
	} 
	catch(PDOException $ex) 
	{
		die("Failed to run query: " . $ex->getMessage()); 
	} 
    
    /* If you want to process the returned xml rather than send it
        to the browser, remove the below line.
    */
    header("Content-Type: application/xml");
    echo pdo2xml($stmt, "decks", "deck");
?>