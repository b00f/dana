<?php 
	
	require("common.php"); 	
?>