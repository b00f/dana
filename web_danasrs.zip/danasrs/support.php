﻿<?php $tab='support'; include('header.php'); ?>


<h3>
Support Dana
</h3>
<p>
Downloading Dana and using it is the biggest support.<br />
Thanks for using Dana! <br />

</p>

<p> Anyway, if you are website developer you can help me on running this website.<br />
as maybe you have noticed I am not so good at designing a website!<br />
I am a bit geek!<br />

</p>

<p>
If you are C++ developer and have a good knowledge about Qt Platform you can contribute on this project. <br />
It's an open source project... <br />

</p>

<p>
If you want to donate, I appreciate it. But in my culture accepting donates is prohibited, but you can pay this website costs...
</p>


 <?include 'footer.php'; ?>
