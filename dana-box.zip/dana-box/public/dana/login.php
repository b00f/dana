<?php
    require("utils.php");

    if(!empty($_SESSION['user']))
    {
        header("Location: private.php");
        die("Redirecting to private.php");
    }

    $submitted_email = "";

    if(!empty($_POST))
    {
		$error = check_user($_POST['email'], $_POST['password']);

		if(empty($error))
		{
			// Redirect the user to the private members-only page.
			header("Location: private.php");
			die("Redirecting to: private.php");
		}
		else
		{
			// Tell the user they failed
			//print("Login Failed.");

			// Show them their username again so all they have to do is enter a new
			// password.  The use of htmlentities prevents XSS attacks.  You should
			// always use htmlentities on user submitted values before displaying them
			// to any users (including the user that submitted them).  For more information:
			// http://en.wikipedia.org/wiki/XSS_attack
			$submitted_email = htmlentities(isset($email)?$email:"", ENT_QUOTES, 'UTF-8');

			echo '<div class="error"><ol>';
			foreach ($error as $key => $values)
			{
				echo '<li>'.$values.'</li>';
			}
			echo '</ol></div>';
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dana - Login</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<form action="login.php" method="post">
  <fieldset>
    <legend>Login Form  </legend>
	<p>Login
	<span class="link"><a href="forgot_password.php">Forgot Password!</a></span> </p>
    <div class="elements">
      <label for="email">Email :</label>
      <input type="text" id="email" name="email" size="25" value="<?php echo $submitted_email; ?>" />
    </div>
    <div class="elements">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" size="25" />
    </div>
    <div class="submit">
      <input type="submit" value="Login" />
    </div>
	<a href="register.php">Create an account. It's free!</a>
  </fieldset>
</form>
</body>
</html>

