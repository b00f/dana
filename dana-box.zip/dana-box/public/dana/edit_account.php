<?php
require_once("utils.php");
 require_once("restricted.php");

// If the user entered a new password, we need to hash it and generate a fresh salt
// for good measure.
if(!empty($_POST))
{
    $error = update_account($_POST['username'], $_POST['password']);

    if(empty($error))
    {
        // Redirect the user to the private members-only page.
        header("Location: private.php");
        die("Redirecting to: private.php");
    }
    else
    {
        echo '<div class="error"><ol>';
        foreach ($error as $key => $values)
        {
            echo '<li>'.$values.'</li>';
        }
        echo '</ol></div>';
    }
 }
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dana - Login</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<form action="edit_account.php" method="post" autocomplete="off">
  <fieldset>
    <legend>Edit Account </legend>
    <p></p>
    <div class="elements">
      <label for="username">Name :</label>
      <input type="text" id="username" name="username" size="25" value="<?php echo htmlentities($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8'); ?>" />
    </div>
    <div class="elements">
      <label for="email">Email :</label>
      <input type="text" id="email" name="email" size="25" value="<?php echo htmlentities($_SESSION['user']['email'], ENT_QUOTES, 'UTF-8'); ?>" disabled="1"/>
    </div>
    <div class="elements">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" size="25" value="" />
    </div>
    <div class="submit">
      <input type="submit" value="Submit" />
    </div>
  </fieldset>
</form>
</body>
</html>