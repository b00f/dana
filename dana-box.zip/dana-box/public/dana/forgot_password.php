<?php
    require_once("utils.php");

    $error = array();//Declare An Array to store any error message

    // This variable will be used to re-display the user's username to them in the
    // login form if they fail to enter the correct password.  It is initialized here
    // to an empty value, which will be shown if the user has not submitted the form.
    $submitted_email = '';

    // This if statement checks to determine whether the login form has been submitted
    // If it has, then the login code is run, otherwise the form is displayed
    if(!empty($_POST))
    {
        $email = $_POST['email'];

        // This query retreives the user's information from the database using
        // their username.
        $query = "
            SELECT
                id,
                username,
                password,
                salt,
                email,
                activation
            FROM users
            WHERE
                email = :email
        ";

        // The parameter values
        $query_params = array(
            ':email' => $email
        );

        try
        {
            // Execute the query against the database
            $stmt = $db->prepare($query);

            $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            // Note: On a production website, you should not output $ex->getMessage().
            // It may provide an attacker with helpful information about your code.
            die("Failed to run query: " . $ex->getMessage());
        }

        // This variable tells us whether the user has successfully logged in or not.
        // We initialize it to false, assuming they have not.
        // If we determine that they have entered the right details, then we switch it to true.
        $login_ok = false;

        // Retrieve the user data from the database.  If $row is false, then the username
        // they entered is not registered.
        $row = $stmt->fetch();
        if($row)
        {
            $activation = $row['activation'];
            $email = $row['email'];

            if(!is_null($activation))
            {
                send_confirmation_letter($activation, $email);

                echo '<div class="error">Your account has not been activated yet. Another confirmation email has been sent to ' . $Email .
                ' Please click on the Activation Link to activate your account. </div>';
            }
            else
            {
                //Generate a RANDOM MD5 Hash for a password
                $random_password=md5(uniqid(rand()));

                //Take the first 8 digits and use them as the password we intend to email the user
                $emailpassword=substr($random_password, 0, 8);

                $salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));

                $password=hash_password($emailpassword, $salt);

                 $query = "
                    UPDATE users
                    SET
                        password=:password,
                        salt=:salt
                    WHERE
                        id = :user_id";

                $query_params = array(
                    ':password' => $password,
                    ':salt' => $salt,
                    ':user_id' => $row['id']
                );

                try
                {
                    // Execute the query to create the user
                    $stmt = $db->prepare($query);

                    $stmt->execute($query_params);

                    send_password($emailpassword, $email);

                    echo ('<div class="success">The new password has sent to your email. Please check your email. You may now <a href="login.php">Log in</a></div>');
                 }
                catch(PDOException $ex)
                {
                    // Note: On a production website, you should not output $ex->getMessage().
                    // It may provide an attacker with helpful information about your code.
                    die("Failed to run query: " . $ex->getMessage());
                }
            }
        }
        else
        {
            $error[] = ("This email is not registered. You can register <a href='register.php'>here</a> for free!");

            $submitted_email = $email;
        }
    }
    else
    {
        $submitted_email = htmlentities(isset($_GET['email'])?$_GET['email']:"", ENT_QUOTES, 'UTF-8');
    }

    if(empty($error)==false)
    {
        echo '<div class="error"><ol>';
        foreach ($error as $key => $values)
        {
            echo '<li>'.$values.'</li>';
        }
        echo '</ol></div>';
    }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dana - Forgot Password</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<form action="forgot_password.php" method="post">
  <fieldset>
    <legend>Forgot Password</legend>
    <p>Recovering Password by Email
    <span class="link"><a href="login.php">Log in</a></span></p>
    <div class="elements">
      <label for="email">Email :</label>
      <input type="text" id="email" name="email" size="25" value="<?php echo $submitted_email; ?>" />
    </div>
    <div class="submit">
      <input type="submit" value="Recover" />
    </div>
  </fieldset>
</form>
</body>
</html>

