<?php

	require_once("restricted.php");

    header("Location: private.php");
    die("Redirecting to private.php");
?>