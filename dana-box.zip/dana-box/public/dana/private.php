<?php
    require_once("utils.php");
    require_once("restricted.php");

?>
Hello <?php echo htmlentities($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8'); ?>, secret content!<br />
<a href="edit_account.php">Edit Account</a><br />
<a href="logout.php">Logout</a>

<br>
Your decks:<br>

<?php
    $rows = get_decks_by_user_id($_SESSION['user']['id']);

    for($index = 0; $index < count ($rows); $index ++)
    {
        echo $rows[$index]['name'];
        echo ' <a href="delete_deck.php?deck_id=' . $rows[$index]['id'] . '">delete</a>';
        echo "<br/>";
    }
    ///var_dump($rows);
?>