<?php

include("common.php");


if (isset($_GET['email']) && preg_match('/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/', $_GET['email']))
{
    $email = $_GET['email'];
}
if (isset($_GET['key']) && (strlen($_GET['key']) == 40))
{
    $key = $_GET['key'];
}

if (isset($email) && isset($key))
{
	$select = "SELECT 1 FROM  users WHERE(email ='$email' AND activation IS NULL)";
	$stmt = $db->prepare($select);

    $stmt->execute();

	if ($stmt->rowCount()==1)//if update query was successfull
	{
		header("Location: login.php");
		die("Redirecting to login.php");
	}

	// Update the database to set the "activation" field to null
    $update = "UPDATE users SET activation=NULL WHERE(email ='$email' AND activation='$key')LIMIT 1";
	$stmt = $db->prepare($update);

    $stmt->execute();

    // Print a customized message:
    if ($stmt->rowCount()==1)//if update query was successfull
    {
		header("Location: login.php");
		die("Redirecting to login.php");
    }

	die('Oops !Your account could not be activated. Please recheck the link or contact the system administrator.');
}
else
{
    die('An error Occured.');
}
?>
