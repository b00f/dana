<?php

require_once("utils.php");
require_once("url_to_absolute.php");

if(!empty($_POST))
{
    $action = $_POST['action'];

    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    if($action=="login")
    {
        $dana_ver = $_POST['version'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $error = check_user($email, $password, $dana_ver);

        if(!empty($error))
        {
            foreach ($error as $key => $values)
            {
                echo $values.'<br/>';
            }
        }
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="logout")
    {
        unset($_SESSION['user']);
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="share")
    {
        $dana_ver  = $_POST['version'];
        $name      = $_POST['name'];
        $desc      = $_POST['desc'];
        $author    = $_POST['author'];
        $tags      = $_POST['tags'];
        $cards_no  = $_POST['cards_no'];
        $guid      = strtoupper( $_POST['guid'] );

        share_deck($dana_ver, $name, $desc, $author, $tags, $cards_no, $guid);
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="deck_list")
    {
        $rows = get_decks();

       /// header("Content-Type: application/xml");
        echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n";
        echo "<dana>";
        echo "<decks>";

        for($index = 0; $index < count ($rows); $index ++)
        {
            $votes = get_votes($rows[$index]['id']);

            ///var_dump(get_object_vars($row));
            echo '<deck>';

            echo '<id>'              . $rows[$index]['id']           . '</id>';
            echo '<name><![CDATA['   . $rows[$index]['name']         . ']]></name>';
            echo '<desc><![CDATA['   . $rows[$index]['description']  . ']]></desc>';
            echo '<tags><![CDATA['   . $rows[$index]['tags']         . ']]></tags>';
            echo '<author><![CDATA[' . $rows[$index]['author']       . ']]></author>';
            echo '<guid>'            . $rows[$index]['guid']         . '</guid>';
            echo '<rating>'          . $rows[$index]['rating']       . '</rating>';
            echo '<votes>'           . $votes                        . '</votes>';
            echo '<downloads>'       . $rows[$index]['downloads']    . '</downloads>';
            echo '<inhand>'          . $rows[$index]['cards_no']     . '</inhand>';
            echo '<flags>'           . $rows[$index]['flags']        . '</flags>';
            echo '<created>'         . $rows[$index]['created']      . '</created>';
            echo '<updated>'         . $rows[$index]['updated']      . '</updated>';
            echo '<path>' . $base_url. '/dana/download.php?deck_id=' . $rows[$index]['id'] . '</path>';
            echo '<icon>' . $base_url. $rows[$index]['icon'] . '</icon>';

            echo '</deck>';
        }

        echo "</decks>";
        echo "</dana>";
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="vote")
    {
        $dana_ver = $_POST['version'];

        vote($_POST['deck_id'], $_POST['rating']);
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="check_deck")
    {
        if(empty($_SESSION['user']))
            echo '-1'; /// not a valid session

        $dana_ver  = $_POST['version'];
        $guid      = strtoupper ($_POST['guid'] );

        $result = check_deck_by_guid($guid);

        echo $result;
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="download")
    {
        $deck_id = $_POST['deck_id'];

        download_deck($deck_id);
    }
    //// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else if($action=="check_update")
    {
        $dana_ver = intval($_POST['version']);
        ///$last_ver = 102;

        ///if($dana_ver < $last_ver)
        ///{
        ///    echo 'A new update available.';
        ///}
    }
}
?>