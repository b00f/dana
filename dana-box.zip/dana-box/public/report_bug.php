﻿<?php $tab='support'; include('header.php'); ?>


<h3>
Report a bug
</h3>
<p>
If you found a bug while using dana, please email it to me (mostafa.sedaghat at gmail)
 <br />


 <?include 'footer.php'; ?>
