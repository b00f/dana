﻿<?php $tab='download'; include('header.php'); ?>

<p>
<br />
</p>
<p>
Dana comes with source code and pre-compiled binary packages for various operation systems.
You can download source code
</p>
<h3>
Binary Packages
</h3>
<ul>
    <li><a href="http://sourceforge.net/projects/dana-box/files/Dana.exe/download/">Windows</a></li>
    <li><a href="http://sourceforge.net/projects/dana-box/files/dana.tar.gz/download/">Linux</a></li>
    <li><a href="http://sourceforge.net/projects/dana-box/files/dana.dmg/download/">Mac Os</a></li>
</ul>


<h4>iPhone, Android</h4>
Comming Soon!
<br />

<h4>Source</h4>
<a href="https://github.com/m-o-s-t-a-f-a/dana">dana at github</a>
<br />
<?include 'footer.php'; ?>